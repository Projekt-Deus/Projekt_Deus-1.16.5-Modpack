# Projekt_Deus-1.16.5-Modpack

This Project is made for and being tested on Minecraft 1.16.5 forge-36.0.0<br>
to install this pack just download the zip and import it into curseforge.
